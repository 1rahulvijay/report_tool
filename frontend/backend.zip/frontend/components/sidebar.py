import reflex as rx
from frontend.state import AppState


def sidebar() -> rx.Component:
    """The left navigation indicating Datasets and Metadata."""
    return rx.box(
        # Top Section: Active Dataset Information Card
        rx.box(
            rx.text(
                "Active Dataset",
                class_name="text-[10px] font-bold uppercase tracking-wider text-text-muted mb-1.5",
            ),
            rx.box(
                rx.box(
                    rx.icon(tag="table", size=16),
                    class_name="bg-blue-100 p-1.5 rounded text-blue-700",
                ),
                rx.box(
                    rx.text(
                        rx.cond(
                            AppState.selected_dataset == "",
                            "No Dataset",
                            AppState.selected_dataset,
                        ),
                        class_name="text-[11px] font-bold text-text-main leading-tight break-all",
                    ),
                    rx.text(
                        rx.icon(tag="rows-4", size=12, class_name="mr-1"),
                        f"{AppState.total_row_count} Rows",
                        class_name="text-[10px] text-text-muted flex items-center mt-0.5",
                    ),
                    class_name="flex-1 min-w-0",
                ),
                class_name="flex items-center gap-2 mb-2 p-1.5 bg-white rounded border border-border-light shadow-sm",
            ),
            # Searchable Dataset List
            rx.box(
                rx.hstack(
                    rx.box(
                        rx.icon(
                            tag="search",
                            size=14,
                            class_name="absolute left-2 top-1/2 -translate-y-1/2 text-text-muted",
                        ),
                        rx.input(
                            placeholder="Search...",
                            value=AppState.dataset_search_text,
                            on_change=AppState.set_dataset_search_text,
                            class_name="w-full bg-slate-50 border-none rounded pl-7 pr-1 py-1 text-[10px] outline-none",
                        ),
                        class_name="relative flex-1",
                    ),
                    rx.button(
                        rx.icon(tag="refresh-cw", size=12),
                        on_click=AppState.fetch_datasets,
                        class_name="p-1 bg-slate-50 rounded text-text-muted hover:text-accent cursor-pointer",
                    ),
                    class_name="p-1.5 border-b border-border-light bg-slate-50 sticky top-0 z-10",
                ),
                rx.box(
                    rx.vstack(
                        rx.foreach(
                            AppState.filtered_datasets,
                            lambda name: rx.button(
                                rx.hstack(
                                    rx.cond(
                                        AppState.selected_dataset == name,
                                        rx.icon(tag="check", size=10),
                                        rx.fragment(),
                                    ),
                                    rx.text(
                                        name, class_name="break-all text-left w-full"
                                    ),
                                    align="center",
                                    spacing="1",
                                    width="100%",
                                ),
                                on_click=lambda: AppState.select_dataset(name),
                                class_name=rx.cond(
                                    AppState.selected_dataset == name,
                                    "w-full justify-start px-2 py-1 text-[10px] font-bold bg-accent text-white rounded-none",
                                    "w-full justify-start px-2 py-1 text-[10px] font-medium text-text-main hover:bg-slate-100 rounded-none bg-transparent border-none cursor-pointer",
                                ),
                            ),
                        ),
                        spacing="0",
                        width="100%",
                    ),
                    class_name="max-h-[120px] overflow-y-auto custom-scrollbar",
                ),
                class_name="border border-border-light rounded overflow-hidden bg-white mb-1",
            ),
            class_name="p-2 border-b border-border-light bg-surface-offset",
        ),
        # Middle Section: Visible Columns
        rx.cond(
            AppState.selected_dataset != "",
            rx.box(
                rx.box(
                    rx.text(
                        "Visible Columns",
                        class_name="text-[10px] font-bold uppercase text-text-muted py-1.5 sticky top-0 z-20",
                    ),
                ),
                # Column Search, Actions, and List inside a White Box
                rx.box(
                    rx.box(
                        rx.box(
                            rx.icon(
                                tag="search",
                                size=14,
                                class_name="absolute left-2 top-1/2 -translate-y-1/2 text-text-muted",
                            ),
                            rx.input(
                                placeholder="Filter columns...",
                                value=AppState.column_search_text,
                                on_change=AppState.set_column_search_text,
                                class_name="w-full bg-slate-50 border-none rounded pl-7 pr-2 py-1 text-[10px] outline-none",
                            ),
                            class_name="relative",
                        ),
                        rx.hstack(
                            rx.button(
                                "Select All",
                                on_click=AppState.select_all_columns,
                                variant="ghost",
                                class_name="text-[9px] font-bold uppercase text-accent px-1.5 py-0.5 rounded hover:bg-accent/10 cursor-pointer",
                            ),
                            rx.button(
                                "Unselect All",
                                on_click=AppState.unselect_all_columns,
                                variant="ghost",
                                class_name="text-[9px] font-bold uppercase text-text-muted px-1.5 py-0.5 rounded hover:bg-slate-100 cursor-pointer",
                            ),
                            rx.cond(
                                AppState.columns_changed,
                                rx.button(
                                    "Reset",
                                    on_click=AppState.clear_column_filters,
                                    variant="ghost",
                                    class_name="text-[9px] font-bold uppercase text-accent px-1.5 py-0.5 rounded hover:bg-accent/10 cursor-pointer",
                                ),
                            ),
                            spacing="3",
                            class_name="mt-1.5",
                        ),
                        class_name="p-2 border-b border-border-light bg-slate-50",
                    ),
                    rx.box(
                        rx.vstack(
                            rx.foreach(AppState.filtered_columns, column_toggle_item),
                            spacing="0",
                            width="100%",
                            class_name="bg-white",
                        ),
                        class_name="flex-1 overflow-y-auto custom-scrollbar p-1",
                    ),
                    class_name="border border-border-light rounded overflow-hidden bg-white mb-2 flex flex-col min-h-0 shadow-sm",
                ),
                class_name="p-2 flex flex-col flex-1 min-h-0 overflow-hidden",
            ),
            rx.box(class_name="flex-1 bg-surface-offset"),
        ),
        class_name="w-[300px] bg-surface-offset border-r border-border-light flex flex-col shrink-0 z-10 h-full overflow-hidden",
    )


def column_toggle_item(column: dict) -> rx.Component:
    """Renders a single checkbox styling simulating the HTML layout for an individual column."""
    name = column["name"]
    is_visible = AppState.visible_columns.contains(name)

    return rx.box(
        rx.checkbox(
            rx.text(name, class_name="text-[10px] leading-tight break-all"),
            checked=is_visible,
            is_disabled=rx.cond(
                AppState.aggregations.length() > 0,
                ~AppState.aggregation_group_by.contains(name),
                False,
            ),
            on_change=lambda _: AppState.toggle_column_visibility(name),
            color_scheme="blue",
            size="2",
        ),
        class_name=rx.cond(
            rx.cond(
                AppState.aggregations.length() > 0,
                ~AppState.aggregation_group_by.contains(name),
                False,
            ),
            "flex items-start gap-1.5 px-1.5 py-0.5 rounded opacity-50 cursor-not-allowed",
            "flex items-start gap-1.5 px-1.5 py-0.5 rounded hover:bg-white hover:shadow-sm cursor-pointer group transition-all",
        ),
    )
