import reflex as rx
from frontend.state import AppState
from frontend.components.join_builder import join_modal
from frontend.components.filter_modal import filter_modal
from frontend.components.aggregation_builder import aggregation_modal
from frontend.components.data_vintage import data_vintage_bar


def _render_row(row_data: list) -> rx.Component:
    """Renders a single row in the data grid matching the HTML."""
    return rx.table.row(
        rx.table.cell(
            rx.checkbox(color_scheme="blue", size="2"),
            class_name="p-2 text-center border-l-4 border-transparent",  # Simplified active border
        ),
        rx.foreach(
            row_data,
            lambda cell: rx.table.cell(
                cell,
                class_name="p-3 text-slate-600 border-b border-[#f1f5f9] whitespace-nowrap",
            ),
        ),
        class_name="group hover:bg-slate-50 transition-colors bg-white border-b border-border-light text-[11px] text-text-main",
    )


def _render_header(col_name: str) -> rx.Component:
    """Renders a column header cell representing the HTML sortable columns."""
    return rx.table.column_header_cell(
        rx.box(
            rx.box(rx.text(col_name), class_name="flex items-center gap-2"),
            rx.icon(
                tag="chevron-down",
                size=16,
                class_name="opacity-0 group-hover:opacity-100 text-slate-400",
                aria_hidden="true",
            ),
            class_name="flex items-center justify-between pointer",
        ),
        aria_label=f"Sort by {col_name}",
        role="columnheader",
        tab_index=0,
        class_name="group p-3 border-b border-r border-border-light text-[10px] font-bold text-text-muted uppercase tracking-wider hover:bg-slate-100 cursor-pointer transition-colors bg-slate-50",
    )


def datagrid() -> rx.Component:
    """The main dynamic workspace table reflecting the provided layout."""
    return rx.box(
        # Top Action Bar
        rx.box(
            rx.box(
                rx.box(
                    rx.cond(
                        AppState.selected_dataset == "",
                        rx.heading(
                            "No Dataset Selected",
                            class_name="text-text-main text-2xl font-bold",
                        ),
                        rx.heading(
                            AppState.selected_dataset,
                            class_name="text-text-main text-2xl font-bold",
                        ),
                    ),
                    rx.text(
                        "Detailed data viewing interface",
                        class_name="text-text-muted text-sm mt-1",
                    ),
                ),
                rx.box(
                    rx.menu.root(
                        rx.menu.trigger(
                            rx.button(
                                rx.cond(
                                    AppState.is_exporting,
                                    rx.hstack(
                                        rx.spinner(size="1"),
                                        rx.text("Exporting..."),
                                        align="center",
                                        spacing="2",
                                    ),
                                    rx.hstack(
                                        rx.icon(
                                            tag="download", size=18, aria_hidden="true"
                                        ),
                                        rx.text("Export"),
                                        rx.icon(
                                            tag="chevron-down",
                                            size=14,
                                            aria_hidden="true",
                                        ),
                                        align="center",
                                        spacing="2",
                                    ),
                                ),
                                disabled=~AppState.can_export,
                                aria_label="Export data options",
                                class_name="px-3 py-1.5 bg-accent hover:bg-blue-600 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-md text-sm font-bold shadow-md shadow-blue-500/20 transition-all flex items-center gap-1.5 cursor-pointer",
                            )
                        ),
                        rx.menu.content(
                            rx.menu.item(
                                "Export as Excel (.xlsx)",
                                on_click=AppState.export_excel,
                                class_name=rx.cond(
                                    AppState.can_export_excel,
                                    "cursor-pointer",
                                    "cursor-not-allowed text-slate-400",
                                ),
                            ),
                            rx.menu.item(
                                "Export as CSV (.csv)",
                                on_click=AppState.export_csv,
                                class_name="cursor-pointer",
                            ),
                        ),
                    ),
                    rx.box(
                        rx.cond(
                            AppState.is_virtual_scroll,
                            rx.button(
                                rx.icon(tag="layers", size=16, aria_hidden="true"),
                                "Virtual Mode",
                                on_click=AppState.toggle_virtual_scroll,
                                aria_label="Switch to paginated mode",
                                class_name="px-3 py-1.5 bg-green-500 text-white rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                            ),
                            rx.button(
                                rx.icon(tag="list", size=16, aria_hidden="true"),
                                "Paginated",
                                on_click=AppState.toggle_virtual_scroll,
                                aria_label="Switch to virtual scroll mode",
                                class_name="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                            ),
                        ),
                        class_name="ml-2",
                    ),
                    rx.box(
                        rx.cond(
                            AppState.use_oracle_in_memory,
                            rx.button(
                                rx.icon(tag="zap", size=16, aria_hidden="true"),
                                "In-Memory ON",
                                on_click=AppState.toggle_oracle_in_memory,
                                aria_label="Disable Oracle In-Memory execution",
                                class_name="px-3 py-1.5 bg-orange-500 text-white rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                            ),
                            rx.button(
                                rx.icon(tag="zap-off", size=16, aria_hidden="true"),
                                "In-Memory OFF",
                                on_click=AppState.toggle_oracle_in_memory,
                                aria_label="Enable Oracle In-Memory execution",
                                class_name="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                            ),
                        ),
                        class_name="ml-2",
                    ),
                    class_name="flex items-center gap-2",
                ),
                class_name="flex items-center justify-between",
            ),
            # Filter Action Bar
            rx.box(
                rx.box(
                    rx.icon(
                        tag="search",
                        aria_hidden="true",
                        class_name="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 size-4",
                    ),
                    rx.input(
                        placeholder="Search values in columns...",
                        value=AppState.search_value_text,
                        on_change=AppState.set_search_value_text,
                        aria_label="Search grid data globally",
                        class_name="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg leading-5 bg-slate-50 placeholder-slate-500 focus:outline-none focus:bg-white focus:ring-1 focus:ring-accent focus:border-accent sm:text-sm shadow-sm transition-all",
                        style={"outline": "none"},
                    ),
                    rx.box(
                        rx.text(
                            "⌘K",
                            aria_hidden="true",
                            class_name="inline-flex items-center border border-slate-200 rounded px-2 text-sm font-sans font-medium text-slate-400",
                        ),
                        class_name="absolute inset-y-0 right-0 pr-3 flex items-center",
                    ),
                    class_name="relative flex-1 max-w-2xl",
                ),
                rx.box(
                    rx.cond(
                        AppState.has_active_filters
                        | (AppState.joins.length() > 0)
                        | (AppState.aggregations.length() > 0),
                        rx.button(
                            "Reset All",
                            on_click=AppState.reset_all,
                            aria_label="Reset all filters, joins, and aggregations",
                            class_name="text-xs text-red-500 hover:text-red-600 font-bold ml-2 bg-transparent border-none cursor-pointer",
                        ),
                    ),
                    rx.cond(
                        AppState.has_active_filters,
                        rx.button(
                            "Clear Filters",
                            on_click=AppState.clear_filters,
                            aria_label="Clear active filters",
                            class_name="text-xs text-slate-400 hover:text-red-500 font-medium ml-2 bg-transparent border-none cursor-pointer",
                        ),
                    ),
                    rx.cond(
                        AppState.joins.length() > 0,
                        rx.button(
                            "Clear Joins",
                            on_click=AppState.reset_joins,
                            aria_label="Clear dataset joins",
                            class_name="flex items-center gap-1 text-xs text-slate-400 hover:text-red-500 font-medium px-2 py-1 bg-transparent border-none cursor-pointer",
                        ),
                    ),
                    rx.cond(
                        AppState.aggregations.length() > 0,
                        rx.button(
                            "Clear Aggregations",
                            on_click=AppState.clear_aggregations,
                            aria_label="Clear active aggregations",
                            class_name="flex items-center gap-1 text-xs text-slate-400 hover:text-red-500 font-medium px-2 py-1 bg-transparent border-none cursor-pointer",
                        ),
                    ),
                    rx.button(
                        rx.icon(tag="git-pull-request", size=16, aria_hidden="true"),
                        "Join Datasets",
                        on_click=AppState.toggle_join_modal,
                        aria_label="Open join datasets modal",
                        class_name="flex items-center gap-1 text-xs text-accent hover:text-blue-700 font-medium px-2 py-1 bg-transparent border-none cursor-pointer",
                    ),
                    rx.button(
                        rx.icon(tag="filter", size=16, aria_hidden="true"),
                        "More Filters",
                        on_click=AppState.toggle_filter_modal,
                        aria_label="Open advanced filters modal",
                        class_name="flex items-center gap-1 text-xs text-accent hover:text-blue-700 font-medium px-2 py-1 bg-transparent border-none cursor-pointer",
                    ),
                    rx.button(
                        rx.icon(tag="group", size=16, aria_hidden="true"),
                        "Aggregation Builder",
                        on_click=AppState.toggle_aggregation_modal,
                        aria_label="Open aggregation builder modal",
                        class_name="flex items-center gap-1 text-xs text-accent hover:text-blue-700 font-medium px-2 py-1 bg-transparent border-none cursor-pointer",
                    ),
                    class_name="flex items-center gap-2 flex-wrap flex-1 justify-end",
                ),
                class_name="flex items-center gap-4 mt-2",
            ),
            class_name="bg-white border-b border-border-light px-6 pt-5 pb-3 flex flex-col gap-4 shadow-sm z-10 w-full",
        ),
        # Inject the invisible modals here so they render safely when triggered
        filter_modal(),
        join_modal(),
        aggregation_modal(),
        # Data Vintage partition selector (only shown for partitioned tables)
        data_vintage_bar(),
        # The Table Area
        rx.box(
            rx.cond(
                AppState.visible_columns.length() == 0,
                # Friendly Empty State Illustration
                rx.box(
                    rx.center(
                        rx.vstack(
                            rx.icon(
                                tag="layout-template",
                                size=64,
                                class_name="text-slate-200 mb-2",
                            ),
                            rx.heading(
                                "No columns selected",
                                size="4",
                                class_name="text-slate-400 font-bold",
                            ),
                            rx.text(
                                "Use the left sidebar to select columns you want to display in the grid.",
                                class_name="text-slate-400 text-sm max-w-xs text-center",
                            ),
                            rx.button(
                                "Select All Columns",
                                on_click=AppState.select_all_columns,
                                class_name="mt-4 px-4 py-2 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-lg text-sm font-medium border border-slate-200 transition-colors cursor-pointer",
                            ),
                            align="center",
                            spacing="1",
                        ),
                        class_name="h-full",
                    ),
                    class_name="flex-1 bg-[#f8fafc] flex items-center justify-center p-20",
                ),
                # The Data Grid
                rx.table.root(
                    rx.table.header(
                        rx.table.row(
                            # Checkbox header
                            rx.table.column_header_cell(
                                rx.checkbox(color_scheme="blue", size="2"),
                                class_name="p-2 border-b border-border-light w-12 text-center bg-slate-50",
                            ),
                            rx.foreach(AppState.table_headers, _render_header),
                        ),
                        class_name="bg-slate-50 sticky top-0 z-10 shadow-[0_1px_3px_0_rgba(0,0,0,0.1)]",
                    ),
                    rx.table.body(
                        rx.foreach(AppState.table_data, _render_row),
                        rx.cond(
                            AppState.is_virtual_scroll,
                            rx.cond(
                                AppState.page_number < AppState.total_pages,
                                rx.table.row(
                                    rx.table.cell(
                                        rx.box(
                                            rx.cond(
                                                AppState.is_fetching_more,
                                                rx.spinner(size="1", color="blue"),
                                                rx.button(
                                                    "Load More Results",
                                                    on_click=AppState.next_page,
                                                    class_name="text-xs text-accent hover:underline bg-transparent border-none cursor-pointer",
                                                ),
                                            ),
                                            class_name="flex items-center justify-center p-4 bg-slate-50 w-full",
                                        ),
                                        col_span=AppState.visible_columns.length() + 1,
                                    ),
                                ),
                            ),
                        ),
                        class_name="divide-y divide-border-light text-xs text-text-main bg-white",
                    ),
                    class_name="w-full text-left border-collapse",
                ),
            ),
            class_name="flex-1 overflow-auto bg-white relative w-full custom-scrollbar",
        ),
        # Pagination Footer (Hidden in Virtual Mode)
        rx.cond(
            AppState.is_virtual_scroll,
            rx.fragment(),
            rx.box(
                rx.box(
                    "Showing ",
                    rx.text(
                        AppState.query_results.length().to(str),
                        as_="span",
                        class_name="text-text-main font-semibold",
                    ),
                    " of ",
                    rx.text(
                        AppState.total_row_count.to(str),
                        as_="span",
                        class_name="text-text-main font-semibold",
                    ),
                    " records",
                    class_name="text-sm text-text-muted",
                ),
                rx.box(
                    rx.button(
                        rx.icon(tag="chevrons-left", size=20, aria_hidden="true"),
                        on_click=AppState.first_page,
                        aria_label="Go to first page",
                        class_name="p-1 rounded hover:bg-slate-100 text-slate-400 bg-transparent border-none cursor-pointer",
                    ),
                    rx.button(
                        rx.icon(tag="chevron-left", size=20, aria_hidden="true"),
                        on_click=AppState.prev_page,
                        aria_label="Go to previous page",
                        class_name="p-1 rounded hover:bg-slate-100 text-slate-400 bg-transparent border-none cursor-pointer",
                    ),
                    rx.box(
                        rx.text(
                            "Page", class_name="text-sm text-text-main font-medium"
                        ),
                        rx.input(
                            value=AppState.page_number.to(str),
                            on_change=AppState.set_page_number,
                            aria_label="Enter page number",
                            class_name="w-12 h-8 text-center text-sm border-slate-300 rounded focus:ring-accent focus:border-accent mx-1",
                            style={"outline": "none"},
                        ),
                        rx.text(
                            f"of {AppState.total_pages}",
                            class_name="text-sm text-text-muted",
                        ),
                        class_name="flex items-center gap-1 mx-2",
                    ),
                    rx.button(
                        rx.icon(tag="chevron-right", size=20, aria_hidden="true"),
                        on_click=AppState.next_page,
                        aria_label="Go to next page",
                        class_name="p-1 rounded hover:bg-slate-100 text-text-main bg-transparent border-none cursor-pointer",
                    ),
                    rx.button(
                        rx.icon(tag="chevrons-right", size=20, aria_hidden="true"),
                        on_click=AppState.last_page,
                        aria_label="Go to last page",
                        class_name="p-1 rounded hover:bg-slate-100 text-text-main bg-transparent border-none cursor-pointer",
                    ),
                    class_name="flex items-center gap-2",
                ),
                class_name="bg-white border-t border-border-light px-6 py-3 flex items-center justify-between shrink-0 w-full z-20 shadow-[0_-1px_3px_0_rgba(0,0,0,0.05)]",
            ),
        ),
        class_name="flex-1 flex flex-col min-w-0 bg-background-light relative w-full overflow-hidden min-h-[300px] h-full",
    )
