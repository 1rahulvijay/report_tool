import reflex as rx


def topnav() -> rx.Component:
    """The sticky top navigation bar."""
    return rx.box(
        # Left branding
        rx.hstack(
            rx.box(
                rx.icon(tag="activity", size=24),
                class_name="size-8 flex items-center justify-center bg-white/10 rounded-lg text-white",
            ),
            rx.box(
                rx.heading(
                    "Aurora",
                    class_name="text-white text-lg font-bold leading-tight tracking-[-0.015em]",
                ),
                rx.text(
                    "Enterprise Data Explorer", class_name="text-xs text-slate-400 font-medium"
                ),
            ),
            class_name="flex items-center gap-4 text-white",
        ),
        # Right controls (Removed as per request)
        rx.box(),
        class_name="flex items-center justify-between whitespace-nowrap bg-primary px-6 py-3 h-16 shrink-0 z-20 shadow-md w-full",
    )
